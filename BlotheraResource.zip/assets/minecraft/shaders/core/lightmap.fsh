#version 330

layout(std140) uniform LightmapInfo {
    float SkyFactor;
    float BlockFactor;
    float NightVisionFactor;
    float DarknessScale;
    float BossOverlayWorldDarkeningFactor;
    float BrightnessFactor;
    vec3 BlockLightTint;
    vec3 SkyLightColor;
    vec3 AmbientColor;
    vec3 NightVisionColor;
} lightmapInfo;

in vec2 texCoord;

out vec4 fragColor;

float get_brightness(float level) {
    return level / (4.0 - 3.0 * level);
}

vec3 notGamma(vec3 color) {
    float maxComponent = max(max(color.x, color.y), color.z);
    float maxInverted = 1.0f - maxComponent;
    float maxScaled = 1.0f - maxInverted * maxInverted * maxInverted * maxInverted;
    return color * (maxScaled / maxComponent);
}

float parabolicMixFactor(float level) {
    return (2.0 * level - 1.0) * (2.0 * level - 1.0);
}

void main() {
    // Calculate block and sky brightness levels based on texture coordinates
    float block_level = floor(texCoord.x * 16) / 15;
    float sky_level = floor(texCoord.y * 16) / 15;

    // Blothera: firelight a little stronger at its brightest.
    float block_brightness = get_brightness(block_level) * lightmapInfo.BlockFactor * 1.15;
    float sky_brightness = get_brightness(sky_level) * lightmapInfo.SkyFactor;

    // Calculate ambient color with or without night vision
    vec3 nightVisionColor = lightmapInfo.NightVisionColor * lightmapInfo.NightVisionFactor;
    vec3 color = max(lightmapInfo.AmbientColor, nightVisionColor);

    // Add sky light
    // Blothera: near a flame the night sky's grey-blue barely mixes in, so it does not dull the fire.
    color += lightmapInfo.SkyLightColor * sky_brightness * (1.0 - 0.6 * clamp(block_brightness, 0.0, 1.0));

    // Add block light
    // Blothera: firelight stays warm right up to the flame. Vanilla whitens it to 90% at the
    // brightest (and darkest), so the tint only showed in half-lit corners and a lit room read grey.
    vec3 BlockLightColor = mix(lightmapInfo.BlockLightTint, vec3(1.0), 0.2 * parabolicMixFactor(block_level));
    // Blothera: firelight given back half the lift the Brightness slider would have given it
    // (the slider is held at Moody for everyone below, which keeps the nights dark, but left
    // firelight falling off steep and dull). The sky and the dark between lights are not lifted.
    vec3 fire = clamp(BlockLightColor * block_brightness, 0.0, 1.0);
    color += mix(fire, notGamma(fire + vec3(1.0e-4)), 0.5);

    // Apply boss overlay darkening effect
    color = mix(color, color * vec3(0.7, 0.6, 0.6), lightmapInfo.BossOverlayWorldDarkeningFactor);

    // Apply darkness effect scale
    color = color - vec3(lightmapInfo.DarknessScale);

    // Apply brightness
    color = clamp(color, 0.0, 1.0);
    vec3 notGamma = notGamma(color);
    // Blothera: the Brightness slider, and a gamma raised past it, light nothing up.
    color = mix(color, notGamma, min(lightmapInfo.BrightnessFactor, 0.00));

    fragColor = vec4(color, 1.0);
}
