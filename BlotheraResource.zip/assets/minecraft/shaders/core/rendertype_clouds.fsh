#version 330

#moj_import <minecraft:fog.glsl>


in float vertexDistance;
in vec4 vertexColor;

out vec4 fragColor;

// Blothera: clouds fade out at the default cloud distance (128 chunks), not at FogCloudsEnd,
// which carries the weather's wind to the terrain shader's swaying plants (terrain.vsh).
const float CLOUDS_END = 2048.0;

void main() {
    vec4 color = vertexColor;
    color.a *= 1.0f - linear_fog_value(vertexDistance, 0, CLOUDS_END);
    fragColor = color;
}
