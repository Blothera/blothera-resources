#version 330

#moj_import <minecraft:fog.glsl>
#moj_import <minecraft:dynamictransforms.glsl>

in float sphericalVertexDistance;
in float cylindricalVertexDistance;

out vec4 fragColor;

// Blothera: the sky fades into the fog at the view distance, not at FogSkyEnd, which carries the
// weather's wind direction to the terrain shader's swaying plants (terrain.vsh). The game sets
// FogSkyEnd to the view distance unless told otherwise, so the sky looks as it did.

void main() {
    fragColor = apply_fog(ColorModulator, sphericalVertexDistance, cylindricalVertexDistance, 0.0, FogRenderDistanceEnd, FogRenderDistanceEnd, FogRenderDistanceEnd, FogColor);
}
