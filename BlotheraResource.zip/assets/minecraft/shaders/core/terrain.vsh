#version 330

#moj_import <minecraft:fog.glsl>
#moj_import <minecraft:globals.glsl>
#moj_import <minecraft:chunksection.glsl>
#moj_import <minecraft:projection.glsl>
#moj_import <minecraft:sample_lightmap.glsl>

in vec3 Position;
in vec4 Color;
in vec2 UV0;
in ivec2 UV2;

uniform sampler2D Sampler2;

out float sphericalVertexDistance;
out float cylindricalVertexDistance;
out vec4 vertexColor;
out vec2 texCoord0;

// Blothera: leaves, grass, flowers, crops, sugar cane and bamboo sway in the weather's wind
// (Harry, 2026-11-02).
//
// Which corners move: the pack's plant models (make_sway.py) mark them where they sit on the
// texture: the face's side edges pulled in 0.06 of a pixel (the key), and its top or foot edge
// a whisker off a whole pixel, in steps of 0.02 (the weight): 1 the middle of a two-block plant,
// 2 the top of a plant, 3 every corner of a stalk (sugar cane, bamboo), 4 the top of a two-block
// plant, 5 every corner of a leaf block (make_leaves.py, our bushy leaves). On the
// texture, not in the height: the game nudges short grass and ferns down a random amount.
// Nothing else carries the key, so nothing else moves.
//
// The wind: the weather sends it in the cloud fade distance, which nothing here draws by
// (make_atmosphere.py, wind()): 1 for each of 32 compass steps it blows toward, plus its
// strength times 0.95. 31.98 or more is no wind sent: still air.
//
// Out of the open sky the wind does not reach: indoors, in caves, under roofs and overhangs.
// Only what stands under nearly the whole sky (sky light 14 or 15) moves (Harry, 2026-11-02:
// "plants indoors and in caves dont sway").
//
// How much: next to nothing in a calm or a light air (10% is a breeze nobody hears), growing
// with the wind to the full sway in a gale (Harry, 2026-11-02: "10% wind is supposed to be
// basically nothing").
//
// Time: GameTime is the world's ticks round a twenty-minute cycle, so every wave below turns a
// whole number of times in it, and nothing jumps when it comes round.

const float TAU = 6.2831853;
const float KEY = 0.06;
const float HANGING_KEY = 0.10;
const float STEP = 0.02;
// A thing that hangs comes back from swayMark as 10 more than its weight.
const int HANGING = 10;

// How far a texture coordinate sits off a whole pixel of the atlas, 0 to 0.5.
float offPixel(float texel) {
    return abs(fract(texel + 0.5) - 0.5);
}

int swayMark(vec2 uv) {
    vec2 texel = uv * vec2(TextureSize);
    float key = offPixel(texel.x);
    bool hanging = abs(key - HANGING_KEY) < 0.006;
    if (!hanging && abs(key - KEY) > 0.006) {
        return 0;
    }
    float weight = offPixel(texel.y);
    float steps = round(weight / STEP);
    if (steps < 1.0 || steps > 5.0 || abs(weight - steps * STEP) > 0.005) {
        return 0;
    }
    return int(steps) + (hanging ? HANGING : 0);
}

float wave(float cycles, float phase) {
    return sin(TAU * cycles * GameTime + phase);
}

vec3 sway(vec3 position, int mark) {
    float carried = FogCloudsEnd;
    vec2 toward = vec2(0.0, 1.0);
    float strength = 0.0;
    if (carried < 31.98) {
        float compassStep = floor(carried + 0.0005);
        strength = clamp((carried - compassStep) / 0.95, 0.0, 1.0);
        float yaw = radians(compassStep * 11.25);
        toward = vec2(-sin(yaw), cos(yaw));
        // As the wind is seen and heard (weather/WindEffects, WeatherListener): no wind bits below
        // 15%, no gusts heard below 30%, so nothing much moving below about 12%, growing from
        // there to the full sway in a gale (Harry, 2026-11-02: "make it realistic compared to the
        // particles and sound volume").
        strength = pow(clamp((strength - 0.12) / 0.88, 0.0, 1.0), 1.2);
    }
    vec2 across = vec2(-toward.y, toward.x);

    vec3 world = position + vec3(ChunkPosition);
    float sky = float(UV2.y) / 240.0;
    float open = smoothstep(0.86, 0.99, sky);

    // Gusts: patches of stronger wind drifting and swelling over the land, stronger in a gale.
    // Not tied to the wind's direction: a pattern rolling along it was laid out from the world's
    // coordinates, thousands of blocks long, so the least turn of the wind reshuffled every gust
    // at once and the plants flickered.
    float roll = 0.5 + 0.25 * sin(world.x * 0.071 + TAU * 84.0 * GameTime)
            + 0.25 * sin(world.z * 0.093 - TAU * 66.0 * GameTime + sin(world.x * 0.031) * 2.0);
    float gust = mix(1.0, 0.35 + 1.3 * roll * roll, strength);
    // Each plant a little out of step with its neighbours.
    float phase = sin(world.x * 0.83) * 2.1 + cos(world.z * 0.71) * 2.3 + sin((world.x + world.z) * 0.37) * 1.7;

    if (mark > HANGING) {
        // A hanging lantern swung from its hook: pushed downwind and swinging about it, more the
        // lower it hangs (weight 1 to 5, the hook 0), as a pendulum lifts a little at the end of
        // its swing. Lanterns hang under a beam or an eave, which shades them from part of the
        // sky, so a looser test of the open air than a plant's; indoors they hang still.
        float hangOpen = smoothstep(0.7, 0.93, sky);
        float hang = float(mark - HANGING) / 5.0;
        float push = (0.004 + 0.07 * strength) * gust;
        float swing = 0.004 + 0.05 * strength;
        vec2 move = toward * (push + swing * wave(240.0, phase)) + across * swing * 0.4 * wave(300.0, phase * 1.3);
        move *= hang * hangOpen;
        return vec3(move.x, dot(move, move) * 2.0, move.y);
    }
    if (open <= 0.0) {
        return vec3(0.0);
    }

    if (mark == 5) {
        // A leaf tuft's top (make_leaves.py): the leaf block stays still and its tufts bend
        // from their feet, so nothing slides on the ground or wobbles like jelly (Harry,
        // 2026-11-02). A lean downwind and a sway about it that rolls smoothly through the tree,
        // and a quicker stir. Deeper in the canopy the sky's light is less, and so is the wind:
        // the outside of a tree moves, its heart barely.
        float exposed = smoothstep(0.7, 1.0, float(UV2.y) / 240.0) * open;
        float field = dot(world, vec3(0.29, 0.19, 0.23));
        float lean = (0.004 + 0.085 * strength) * gust;
        float reach = (0.005 + 0.115 * strength) * gust;
        float canopy = 0.6 * wave(300.0, field + phase * 0.3) + 0.4 * wave(540.0, field * 1.4 + 1.0);
        float stir = 0.003 + 0.042 * strength;
        vec3 move = vec3(toward.x, 0.0, toward.y) * (lean + reach * canopy);
        move += vec3(wave(900.0, field * 2.1), 0.4 * wave(1020.0, field * 1.7 + 1.0), wave(960.0, field * 2.6 + 2.0)) * stir;
        return move * exposed;
    }

    if (mark == 3) {
        // Sugar cane and bamboo: the whole stalk leaning a little downwind and swaying, the sway
        // rolling up it, the same at every joint so a stalk of any height stays whole. Each block
        // bending from its own foot broke the stalk at every joint (Harry, 2026-11-02: "it clips
        // at the bottom"), and the shader cannot tell which block is in the ground, so the foot
        // moves too: kept small, under half a pixel but in a gale.
        float lean = (0.003 + 0.05 * strength) * gust;
        float swaying = 0.7 + 0.3 * wave(360.0, phase - world.y * 0.25);
        vec2 move = toward * lean * swaying + across * lean * 0.2 * wave(600.0, phase * 1.2 - world.y * 0.3);
        return vec3(move.x, 0.0, move.y) * open;
    }

    float weight = mark == 1 ? 0.5 : (mark == 2 ? 1.0 : (mark == 4 ? 1.7 : 0.0));
    if (weight == 0.0) {
        return vec3(0.0);
    }
    // A steady bend downwind, more than doubling as the wind rises, and a sway about it: slow in
    // a breeze, quicker and shakier in a gale.
    float bend = (0.004 + 0.06 * strength + 0.2 * strength * strength) * gust;
    float swing = 0.004 + 0.081 * strength;
    float flutter = wave(420.0, phase) * (1.0 - 0.5 * strength)
            + wave(1080.0, phase * 1.7) * (0.3 + 0.5 * strength)
            + wave(1920.0, phase * 2.3) * 0.2 * strength;
    vec2 move = toward * (bend + swing * flutter) + across * swing * 0.35 * wave(660.0, phase * 1.3);
    move *= weight * open;
    // A stalk bent over is a little shorter.
    return vec3(move.x, -dot(move, move) * 0.6, move.y);
}

void main() {
    vec3 position = Position;
    int mark = swayMark(UV0);
    if (mark > 0) {
        position += sway(Position, mark);
    }
    vec3 pos = position + (ChunkPosition - CameraBlockPos) + CameraOffset;
    gl_Position = ProjMat * ModelViewMat * vec4(pos, 1.0);

    sphericalVertexDistance = fog_spherical_distance(pos);
    cylindricalVertexDistance = fog_cylindrical_distance(pos);
    vertexColor = Color * sample_lightmap(Sampler2, UV2);
    texCoord0 = UV0;
}
