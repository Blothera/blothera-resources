#version 330

#moj_import <minecraft:fog.glsl>
#moj_import <minecraft:globals.glsl>
#moj_import <minecraft:chunksection.glsl>
#moj_import <minecraft:projection.glsl>
#moj_import <minecraft:sample_lightmap.glsl>

in vec3 Position;
in vec4 Color;
in vec2 UV0;
in ivec2 UV2;

uniform sampler2D Sampler2;

out float sphericalVertexDistance;
out float cylindricalVertexDistance;
out vec4 vertexColor;
out vec2 texCoord0;

// Blothera: leaves, grass, flowers and crops sway in the weather's wind (Harry, 2026-11-02).
//
// Which corners move: the pack's plant models (make_sway.py) set them a whisker off a whole
// pixel, in steps of 0.02 of a pixel. 1 is the middle of a two-block plant, 2 the top of a
// plant, 4 the top of a two-block plant, 5 every corner of a leaf block. Nothing else moves.
//
// The wind: the weather sends it in the cloud fade distance, which nothing here draws by
// (make_atmosphere.py, wind()): 2 for each of 16 compass steps it blows toward, plus its
// strength times 1.9. 32 or more is no wind sent: still air.
//
// Time: GameTime is the world's ticks round a twenty-minute cycle, so every wave below turns a
// whole number of times in it, and nothing jumps when it comes round.

const float TAU = 6.2831853;
const float STEP = 0.02;

int swayMark(float y) {
    float pixel = fract(y * 16.0);
    if (pixel > 0.005 && pixel < 0.13) {
        return int(round(pixel / STEP));
    }
    if (pixel > 0.87 && pixel < 0.995) {
        return int(round((1.0 - pixel) / STEP));
    }
    return 0;
}

float wave(float cycles, float phase) {
    return sin(TAU * cycles * GameTime + phase);
}

vec3 sway(vec3 position, int mark) {
    float carried = FogCloudsEnd;
    vec2 toward = vec2(0.0, 1.0);
    float strength = 0.0;
    if (carried < 31.95) {
        float compassStep = floor(carried * 0.5 + 0.001);
        strength = clamp((carried - compassStep * 2.0) / 1.9, 0.0, 1.0);
        float yaw = radians(compassStep * 22.5);
        toward = vec2(-sin(yaw), cos(yaw));
    }
    vec2 across = vec2(-toward.y, toward.x);

    vec3 world = position + vec3(ChunkPosition);

    // Gusts rolling over the land downwind, about five blocks a second, stronger in a gale.
    float roll = 0.5 + 0.5 * sin(dot(world.xz, toward) * 0.1 - TAU * 96.0 * GameTime);
    float gust = mix(1.0, 0.35 + 1.3 * roll * roll, strength);
    // Each plant a little out of step with its neighbours.
    float phase = sin(world.x * 0.83) * 2.1 + cos(world.z * 0.71) * 2.3 + sin((world.x + world.z) * 0.37) * 1.7;

    if (mark == 5) {
        // Leaves shiver and lean a little: the same at a shared corner, so the canopy holds together.
        // Not by the light, which differs between two faces meeting at a corner and would open
        // cracks between them; leaves are nearly always out in the open anyway.
        // Two motions: the whole canopy swaying downwind and back, slowly, its neighbours a little
        // out of step; and each corner rustling on its own, quicker. A breeze moves a leaf about
        // a pixel, a gale a couple (Harry, 2026-11-02: at a third of a pixel they looked still).
        vec3 corner = floor(world + 0.5);
        float leafPhase = sin(corner.x * 1.7 + corner.y * 2.3) * 3.0 + cos(corner.z * 1.3 - corner.y * 0.9) * 3.0;
        float canopy = (0.035 + 0.075 * strength) * gust
                * (0.55 * wave(300.0, phase + corner.y * 0.4) + 0.45 * wave(540.0, phase * 1.3 + corner.y * 0.3));
        float rustle = 0.016 + 0.032 * strength;
        vec3 move = vec3(toward.x, 0.0, toward.y) * canopy;
        move += vec3(wave(1140.0, leafPhase), 0.6 * wave(1320.0, leafPhase * 1.3), wave(1260.0, leafPhase * 0.7)) * rustle;
        return move;
    }

    float weight = mark == 1 ? 0.5 : (mark == 2 ? 1.0 : (mark == 4 ? 1.7 : 0.0));
    // Out of the open sky the wind does not reach a plant: indoors, under a roof, in a cave.
    float open = smoothstep(0.45, 0.95, float(UV2.y) / 240.0);
    if (weight == 0.0 || open <= 0.0) {
        return vec3(0.0);
    }
    // A steady bend downwind, more than doubling as the wind rises, and a sway about it: slow in
    // a breeze, quicker and shakier in a gale.
    float bend = (0.03 + 0.06 * strength + 0.18 * strength * strength) * gust;
    float swing = 0.025 + 0.06 * strength;
    float flutter = wave(420.0, phase) * (1.0 - 0.5 * strength)
            + wave(1080.0, phase * 1.7) * (0.3 + 0.5 * strength)
            + wave(1920.0, phase * 2.3) * 0.2 * strength;
    vec2 move = toward * (bend + swing * flutter) + across * swing * 0.35 * wave(660.0, phase * 1.3);
    move *= weight * open;
    // A stalk bent over is a little shorter.
    return vec3(move.x, -dot(move, move) * 0.6, move.y);
}

void main() {
    vec3 position = Position;
    int mark = swayMark(Position.y);
    if (mark > 0) {
        position += sway(Position, mark);
    }
    vec3 pos = position + (ChunkPosition - CameraBlockPos) + CameraOffset;
    gl_Position = ProjMat * ModelViewMat * vec4(pos, 1.0);

    sphericalVertexDistance = fog_spherical_distance(pos);
    cylindricalVertexDistance = fog_cylindrical_distance(pos);
    vertexColor = Color * sample_lightmap(Sampler2, UV2);
    texCoord0 = UV0;
}
