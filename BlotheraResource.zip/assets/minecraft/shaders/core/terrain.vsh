#version 330

#moj_import <minecraft:fog.glsl>
#moj_import <minecraft:globals.glsl>
#moj_import <minecraft:chunksection.glsl>
#moj_import <minecraft:projection.glsl>
#moj_import <minecraft:sample_lightmap.glsl>

in vec3 Position;
in vec4 Color;
in vec2 UV0;
in ivec2 UV2;

uniform sampler2D Sampler2;

out float sphericalVertexDistance;
out float cylindricalVertexDistance;
out vec4 vertexColor;
out vec2 texCoord0;

// Blothera: leaves, grass, flowers, crops, sugar cane and bamboo sway in the weather's wind, and
// open water is raised into waves by it (Harry, 2026-11-02).
//
// Which corners move: the pack's plant models (make_sway.py) mark them where they sit on the
// texture: the face's side edges pulled in a few hundredths of a pixel (the key, one of five, or
// 0.10 for a thing that hangs), and its top or foot edge
// a whisker off a whole pixel, in steps of 0.02 (the weight): 1 the middle of a two-block plant,
// 2 the top of a plant, 3 every corner of a stalk (sugar cane, bamboo), 4 the top of a two-block
// plant, 5 the top of a leaf tuft (make_leaves.py, our bushy leaves). On the
// texture, not in the height: the game nudges short grass and ferns down a random amount.
// Nothing else carries the key, so nothing else moves.
//
// The wind: the weather sends its strength in the cloud fade distance and its direction in the
// sky's, which nothing here draws by (make_atmosphere.py, wind()): 0.5 to 30.5, the direction two
// whole turns across it. Apart, so the game's blend from one wind to the next over a tick only
// ever reads as the winds between. 31.5 or more is none sent. The strength's number carries the
// season too (weather/Sky, SEASON_BANDS): it is cut into 24 bands of 1.25, twenty days of the year
// each, and the strength sits within its band, kept 0.05 off its foot.
//
// The seasons (Harry, 2026-11-08): grass and leaves the game tints green are turned by the time
// of year. Leaves go gold, orange and red in autumn, a birch gold, patch by patch so no two trees
// match, then brown in winter; grass yellows to straw in autumn and dulls in winter; in summer
// both are a lusher, richer green (Harry, 2026-11-09: summer "doesnt really look very summer like"). Spruce, drawn in one fixed green with its red and blue alike, stays green, and
// so does anything the game draws in its own colours (cherry, pale oak, azalea, flowers). Leaves
// are known by their marks: a tuft's sway mark (5) and the leaf block's own key (0.09, no weight,
// make_leaves.py); every other green the game tints is grass, ferns and vines.
//
// Out of the open sky the wind does not reach: indoors, in caves, under roofs and overhangs.
// Only what stands under nearly the whole sky (sky light 14 or 15) moves (Harry, 2026-11-02:
// "plants indoors and in caves dont sway").
//
// How much: next to nothing in a calm or a light air (10% is a breeze nobody hears), growing
// with the wind to the full sway in a gale (Harry, 2026-11-02: "10% wind is supposed to be
// basically nothing").
//
// Time: GameTime is the world's ticks round a twenty-minute cycle, so every wave below turns a
// whole number of times in it, and nothing jumps when it comes round.

const float TAU = 6.2831853;
// A plant's key is one of five, 0.030 to 0.078 apart by 0.012: which of its five models the game
// picked for the block, at random (make_sway.py). Every corner of one plant carries the same.
const float FIRST_KEY = 0.030;
const float KEY_APART = 0.012;
const float HANGING_KEY = 0.10;
const float STEP = 0.02;
// A thing that hangs comes back from swayMark as 10 more than its weight.
const int HANGING = 10;

// How far a texture coordinate sits off a whole pixel of the atlas, 0 to 0.5.
float offPixel(float texel) {
    return abs(fract(texel + 0.5) - 0.5);
}

// The mark (0 for none, HANGING more for a thing that hangs) and which of its five the plant is.
ivec2 swayMark(vec2 uv) {
    vec2 texel = uv * vec2(TextureSize);
    float key = offPixel(texel.x);
    bool hanging = abs(key - HANGING_KEY) < 0.004;
    float pick = round((key - FIRST_KEY) / KEY_APART);
    if (!hanging && (pick < 0.0 || pick > 4.0 || abs(key - FIRST_KEY - pick * KEY_APART) > 0.004)) {
        return ivec2(0);
    }
    float weight = offPixel(texel.y);
    float steps = round(weight / STEP);
    if (steps < 1.0 || steps > 5.0 || abs(weight - steps * STEP) > 0.005) {
        return ivec2(0);
    }
    return ivec2(int(steps) + (hanging ? HANGING : 0), hanging ? 2 : int(pick));
}

float wave(float cycles, float phase) {
    return sin(TAU * cycles * GameTime + phase);
}

// The season's bands in the strength's number (weather/Sky).
const float SEASON_BANDS = 24.0;
const float BAND_UNITS = 1.25;
const float BAND_MARGIN = 0.05;
const float STRENGTH_UNITS = 1.1;
// The leaf block's own key (make_leaves.py).
const float LEAF_KEY = 0.09;

// The wind as the weather sends it: which way it blows (a unit vector over x and z), how hard it
// is felt, 0 to a little over 1 in a gust in a gale, and how far through the year it is, 0 the
// first light of spring to 1, or -1 for no season sent.
void readWind(out vec2 toward, out float strength, out float year) {
    toward = vec2(0.0, 1.0);
    strength = 0.0;
    year = -1.0;
    if (FogSkyEnd < 31.5) {
        float yaw = radians((FogSkyEnd - 0.5) / 30.0 * 720.0);
        toward = vec2(-sin(yaw), cos(yaw));
    }
    if (FogCloudsEnd < 31.5) {
        float carried = FogCloudsEnd - 0.5;
        float band = clamp(floor(carried / BAND_UNITS), 0.0, SEASON_BANDS - 1.0);
        year = (band + 0.5) / SEASON_BANDS;
        // Up to half again a gale: the weather's gusts, which the whole land answers at once.
        strength = clamp((carried - band * BAND_UNITS - BAND_MARGIN) / STRENGTH_UNITS * 1.5, 0.0, 1.5);
        // As the wind is seen and heard (weather/WindEffects, WeatherListener): no wind bits below
        // 15%, no gusts heard below 30%, so nothing much moving below about 12%, growing from
        // there to the full sway in a gale (Harry, 2026-11-02: "make it realistic compared to the
        // particles and sound volume").
        strength = pow(clamp((strength - 0.12) / 0.88, 0.0, 1.6), 1.2);
    }
}

// Whether a corner is a leaf block's own (not a tuft): its key, and no weight.
bool leafCube(vec2 uv) {
    vec2 texel = uv * vec2(TextureSize);
    return abs(offPixel(texel.x) - LEAF_KEY) < 0.004 && offPixel(texel.y) < 0.004;
}

// Smooth noise over the land, 0 to 1, for which tree turns which colour. Kept to small numbers:
// the land's coordinates run to the hundreds of thousands.
float hash(vec2 p) {
    p = mod(p, 289.0);
    return fract(sin(dot(p, vec2(127.1, 311.7))) * 43758.5453);
}

float landNoise(vec2 p) {
    vec2 at = floor(p);
    vec2 f = fract(p);
    f = f * f * (3.0 - 2.0 * f);
    return mix(mix(hash(at), hash(at + vec2(1.0, 0.0)), f.x),
               mix(hash(at + vec2(0.0, 1.0)), hash(at + vec2(1.0, 1.0)), f.x), f.y);
}

// Rises from a to b, falls from c to d.
float rise(float x, float a, float b, float c, float d) {
    return smoothstep(a, b, x) * (1.0 - smoothstep(c, d, x));
}

// A colour turned to another hue as bright as it was: its brightest part kept, so the light, the
// shade of a face and the corner's shadow on it stay as the game made them.
vec3 turnedTo(vec3 colour, vec3 hue) {
    return hue * (max(colour.r, max(colour.g, colour.b)) / max(hue.r, max(hue.g, hue.b)));
}

// Grass and leaves as the season has them (see the top). Only greens the game tinted: anything it
// draws untinted comes in grey, red, green and blue alike, and water and stems are not green.
vec3 seasonTint(vec3 colour, bool leaf, float year, vec3 world) {
    if (year < 0.0) {
        return colour;
    }
    float top = max(colour.r, max(colour.g, colour.b));
    if (top < 0.02 || colour.g < colour.r * 1.02 || colour.g < colour.b * 1.15) {
        return colour;
    }
    // Spruce: one fixed green, its red and blue alike. Evergreen.
    if (abs(colour.r - colour.b) < 0.05 * colour.g) {
        return colour;
    }
    // Summer comes on over its first days and holds to its end.
    float summer = rise(year, 0.22, 0.28, 0.47, 0.56);
    float autumn = rise(year, 0.52, 0.62, 0.74, 0.82);
    // Winter, and its last of it at the first light of spring, greening over the first days.
    float winter = smoothstep(0.74, 0.84, year) + 1.0 - smoothstep(0.0, 0.05, year);
    if (leaf) {
        float n = landNoise(world.xz * 0.15 + world.y * 0.07);
        // A birch's own fixed green turns gold; the rest gold, orange and red by the patch.
        bool birch = abs(colour.r / colour.g - 0.766) < 0.03 && abs(colour.b / colour.g - 0.509) < 0.03;
        vec3 fall = birch ? mix(vec3(0.88, 0.71, 0.23), vec3(0.85, 0.64, 0.16), n)
                : n < 0.5 ? mix(vec3(0.85, 0.64, 0.16), vec3(0.83, 0.40, 0.11), n * 2.0)
                : mix(vec3(0.83, 0.40, 0.11), vec3(0.66, 0.19, 0.11), n * 2.0 - 1.0);
        // Some trees turn later than others, or not all the way.
        float turned = autumn * (0.7 + 0.3 * landNoise(world.xz * 0.31 + 7.0));
        colour = mix(colour, turnedTo(colour, vec3(0.30, 0.58, 0.12)), summer * 0.45);
        colour = mix(colour, turnedTo(colour, fall), turned);
        colour = mix(colour, turnedTo(colour, vec3(0.48, 0.35, 0.20)), winter * 0.8);
    } else {
        colour = mix(colour, turnedTo(colour, vec3(0.42, 0.72, 0.18)), summer * 0.45);
        colour = mix(colour, turnedTo(colour, vec3(0.71, 0.64, 0.29)), autumn * 0.6);
        colour = mix(colour, turnedTo(colour, vec3(0.56, 0.54, 0.36)), winter * 0.65);
    }
    // Summer's green richer: further from its own grey, as strong sun saturates a meadow.
    float grey = dot(colour, vec3(0.299, 0.587, 0.114));
    colour = clamp(mix(vec3(grey), colour, 1.0 + 0.35 * summer), 0.0, 1.0);
    return colour;
}

// Waves on open water, raised by the wind (Harry, 2026-11-02: "small waves too, obviously scaling
// with wind"): how high the water stands here now, and how it slopes, -1 to 1, for its shading.
// Laid along four fixed ways, each as strong as the wind lies along it and running downwind: never
// along the wind's own way, which is laid out from world coordinates in the thousands, so the
// least turn of the wind would reshuffle every wave at once. A wave whose way turns against the
// wind runs back, but only once it lies across the wind and is too weak to see.
float waves(vec3 world, vec2 toward, out float slope) {
    const vec2 WAYS[4] = vec2[](vec2(1.0, 0.0), vec2(0.7071, 0.7071), vec2(0.0, 1.0), vec2(-0.7071, 0.7071));
    float height = 0.0;
    slope = 0.0;
    for (int i = 0; i < 4; i++) {
        float along = dot(toward, WAYS[i]);
        float share = along * along * 0.5;
        float running = along < 0.0 ? -1.0 : 1.0;
        // Swells about four blocks apart, and ripples on them half as far, running at about a
        // block and a half a second.
        float swell = dot(world.xz, WAYS[i]) * 1.6 - running * TAU * 420.0 * GameTime + float(i) * 1.7;
        float ripple = dot(world.xz, WAYS[i]) * 3.1 - running * TAU * 620.0 * GameTime + float(i) * 2.9;
        height += share * (sin(swell) + 0.35 * sin(ripple));
        slope += share * running * (cos(swell) + 0.35 * cos(ripple));
    }
    return height;
}

vec3 sway(vec3 position, int mark, int pick) {
    vec2 toward;
    float strength;
    float year;
    readWind(toward, strength, year);
    vec2 across = vec2(-toward.y, toward.x);

    vec3 world = position + vec3(ChunkPosition);
    float sky = float(UV2.y) / 240.0;
    // Out of the open sky the wind does not reach. A corner one block shares with the next (the
    // middle of a two-block plant, every joint of a stalk) is moved by each alike, but each
    // block reads its own light, and under the edge of a tree they differ and the plant would
    // tear apart at the joint (Harry, 2026-11-02, the same on water). So those are stilled only
    // where it is properly dark, deep in a cave or a house; a plant on its own block by the open
    // sky as before.
    bool joined = mark == 1 || mark == 3 || mark == 4;
    float open = joined ? smoothstep(0.2, 0.5, sky) : smoothstep(0.86, 0.99, sky);

    // Gusts: patches of stronger wind drifting and swelling over the land, stronger in a gale.
    // Not tied to the wind's direction: a pattern rolling along it was laid out from the world's
    // coordinates, thousands of blocks long, so the least turn of the wind reshuffled every gust
    // at once and the plants flickered.
    float roll = 0.5 + 0.25 * sin(world.x * 0.071 + TAU * 84.0 * GameTime)
            + 0.25 * sin(world.z * 0.093 - TAU * 66.0 * GameTime + sin(world.x * 0.031) * 2.0);
    // Only a little: the gusts themselves are the weather's, sent in the strength, so everything
    // answers a gust together (Harry, 2026-11-02); this only keeps the land from moving as one sheet.
    float gust = mix(1.0, 0.8 + 0.4 * roll, min(strength, 1.0));
    // Each plant a little out of step with its neighbours.
    // Where each plant is in its sway: changing slowly over the land, a fraction of a turn across
    // a block, so the panes of one plant (a flower's crossed panes, both halves of a rose bush)
    // move as one rather than against each other (Harry, 2026-11-02: the rose "is deforming"),
    // and neighbours drift out of step over a few blocks, as wind rolls over a meadow. Every wave
    // below adds to it rather than multiplying it, which would steepen it again.
    float phase = sin(world.x * 0.1) * 1.5 + cos(world.z * 0.08) * 1.5 + sin((world.x - world.z) * 0.05) * 1.5;
    // And each plant a little of its own, by which of its five models it is: a little out of
    // step with its neighbours and reaching a little more or less (Harry, 2026-11-02: "each one
    // should have a little bit of randomness"), the same at every corner of it.
    phase += float(pick - 2) * 0.8;
    float own = 0.88 + 0.06 * float(pick);

    if (mark > HANGING) {
        // A hanging lantern, turned about its hook (the top middle of its block) as one rigid
        // piece, by one angle for the whole of it, so the iron keeps its shape (Harry,
        // 2026-11-02: moving each part by its height bent it). Tilted downwind and swinging
        // about that, a little across too. Everything here is reckoned from the hook, not the
        // corner, so every corner of one lantern turns alike. Lanterns hang under a beam or an
        // eave, which shades them from part of the sky, so a looser test of the open air than a
        // plant's; indoors they hang still. Up to about fifteen degrees in a gale.
        vec3 hook = vec3(floor(world.x) + 0.5, floor(world.y - 0.001) + 1.0, floor(world.z) + 0.5);
        float hangOpen = smoothstep(0.7, 0.93, sky);
        float hookPhase = sin(hook.x * 0.83) * 2.1 + cos(hook.z * 0.71) * 2.3;
        float hookRoll = 0.5 + 0.25 * sin(hook.x * 0.071 + TAU * 84.0 * GameTime)
                + 0.25 * sin(hook.z * 0.093 - TAU * 66.0 * GameTime + sin(hook.x * 0.031) * 2.0);
        float hookGust = mix(1.0, 0.35 + 1.3 * hookRoll * hookRoll, strength);
        vec2 tilt = toward * ((0.004 + 0.12 * strength) * hookGust + (0.004 + 0.09 * strength) * wave(240.0, hookPhase))
                + across * (0.003 + 0.04 * strength) * wave(300.0, hookPhase * 1.3);
        tilt *= hangOpen;
        float angle = length(tilt);
        if (angle < 0.00001) {
            return vec3(0.0);
        }
        vec2 lean = tilt / angle;
        // The axis it turns about: level, at right angles to the way it leans.
        vec3 axis = vec3(-lean.y, 0.0, lean.x);
        vec3 fromHook = world - hook;
        vec3 turned = fromHook * cos(angle) + cross(axis, fromHook) * sin(angle)
                + axis * dot(axis, fromHook) * (1.0 - cos(angle));
        return turned - fromHook;
    }
    if (open <= 0.0) {
        return vec3(0.0);
    }

    if (mark == 5) {
        // A leaf tuft (make_leaves.py), every corner of it: the leaf block stays still and its tufts
        // move whole, foot and all, never held at the foot (Harry, 2026-11-02: "dont make the extra
        // leaves stuff stick to the bottom"); a whole leaf block moving slid on the ground and
        // wobbled like jelly. Leaning downwind, swaying about that as the sway rolls smoothly
        // through the tree, and a quicker stir. Deeper in the canopy the sky's light is less, and so
        // is the wind: the outside of a tree moves, its heart barely.
        float exposed = smoothstep(0.7, 1.0, float(UV2.y) / 240.0) * open;
        float field = dot(world, vec3(0.29, 0.19, 0.23));
        // Combed downwind: the lean grows faster than the sway as the wind rises, so in anything
        // past a breeze the tufts sway about a point downwind and never swing back past upright,
        // and a tree shows which way the wind blows (Harry, 2026-11-02).
        float lean = (0.004 + 0.05 * strength + 0.2 * strength * strength) * gust;
        float reach = 0.004 + 0.06 * strength;
        float canopy = 0.6 * wave(300.0, field + phase * 0.3) + 0.4 * wave(540.0, field * 1.4 + 1.0);
        float stir = 0.003 + 0.042 * strength;
        vec3 move = vec3(toward.x, 0.0, toward.y) * (lean + reach * canopy);
        move += vec3(wave(900.0, field * 2.1), 0.4 * wave(1020.0, field * 1.7 + 1.0), wave(960.0, field * 2.6 + 2.0)) * stir;
        return move * exposed;
    }

    if (mark == 3) {
        // Sugar cane and bamboo: the whole stalk leaning a little downwind and swaying, the sway
        // rolling up it, the same at every joint so a stalk of any height stays whole. Each block
        // bending from its own foot broke the stalk at every joint (Harry, 2026-11-02: "it clips
        // at the bottom"), and the shader cannot tell which block is in the ground, so the foot
        // moves too: kept small, under half a pixel but in a gale.
        float lean = (0.003 + 0.05 * strength) * gust;
        float swaying = 0.7 + 0.3 * wave(360.0, phase - world.y * 0.25);
        vec2 move = toward * lean * swaying + across * lean * 0.2 * wave(600.0, phase + 1.1 - world.y * 0.3);
        return vec3(move.x, 0.0, move.y) * open;
    }

    float weight = mark == 1 ? 0.5 : (mark == 2 ? 1.0 : (mark == 4 ? 1.7 : 0.0));
    if (weight == 0.0) {
        return vec3(0.0);
    }
    // A steady bend downwind, more than doubling as the wind rises, and a sway about it: slow in
    // a breeze, quicker and shakier in a gale.
    float bend = (0.004 + 0.06 * strength + 0.2 * strength * strength) * gust;
    float swing = 0.004 + 0.081 * strength;
    float flutter = wave(420.0, phase) * (1.0 - 0.5 * strength)
            + wave(1080.0, phase + 1.7) * (0.3 + 0.5 * strength)
            + wave(1920.0, phase + 2.9) * 0.2 * strength;
    vec2 move = toward * (bend + swing * flutter) + across * swing * 0.35 * wave(660.0, phase + 0.8);
    move *= weight * open * own;
    // A stalk bent over is a little shorter.
    return vec3(move.x, -dot(move, move) * 0.6, move.y);
}

void main() {
    vec3 position = Position;
    ivec2 marked = swayMark(UV0);
    int mark = marked.x;
    float shading = 1.0;
    if (mark > 0) {
        position += sway(Position, mark, marked.y);
    } else if (abs(fract(Position.y) - 8.0 / 9.0) < 0.002 && Color.b > Color.r) {
        // The top of open water: standing at eight ninths of its block, which nothing in a block
        // model does, and tinted the water's blue, which lava at the same height is not. Only
        // under the open sky, as the plants: indoors and in caves the water lies still.
        vec2 toward;
        float strength;
        float year;
        readWind(toward, strength, year);
        // Its height the same everywhere, small, and its shading only under the open sky. Every
        // corner of the water is shared with the next block, which reads its own light, so any
        // height stilled by the light opened seams wherever the light changed, under a tree's edge
        // and down a tunnel (Harry, 2026-11-02). The shading only colours, so it can be stilled:
        // in a cave the water rises and falls by a few hundredths of a block, unseen, and looks
        // still; in the open its slopes catch the light and the waves show.
        float open = smoothstep(0.86, 0.99, float(UV2.y) / 240.0);
        if (strength > 0.0) {
            float slope;
            float height = waves(Position + vec3(ChunkPosition), toward, slope);
            position.y += height * (0.002 + 0.02 * strength);
            shading = 1.0 + slope * (0.03 + 0.1 * min(strength, 1.0)) * open;
        }
    }
    vec3 pos = position + (ChunkPosition - CameraBlockPos) + CameraOffset;
    gl_Position = ProjMat * ModelViewMat * vec4(pos, 1.0);

    // The season's grass and leaves (see the top). Leaves: a tuft by its sway mark, the block by its key.
    vec2 seasonToward;
    float seasonStrength;
    float year;
    readWind(seasonToward, seasonStrength, year);
    vec4 colour = vec4(seasonTint(Color.rgb, mark == 5 || leafCube(UV0), year, Position + vec3(ChunkPosition)),
            Color.a);

    sphericalVertexDistance = fog_spherical_distance(pos);
    cylindricalVertexDistance = fog_cylindrical_distance(pos);
    vertexColor = colour * sample_lightmap(Sampler2, UV2) * vec4(vec3(shading), 1.0);
    texCoord0 = UV0;
}
