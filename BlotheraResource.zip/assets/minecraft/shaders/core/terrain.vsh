#version 330

#moj_import <minecraft:fog.glsl>
#moj_import <minecraft:globals.glsl>
#moj_import <minecraft:chunksection.glsl>
#moj_import <minecraft:projection.glsl>
#moj_import <minecraft:sample_lightmap.glsl>

in vec3 Position;
in vec4 Color;
in vec2 UV0;
in ivec2 UV2;

uniform sampler2D Sampler2;

out float sphericalVertexDistance;
out float cylindricalVertexDistance;
out vec4 vertexColor;
out vec2 texCoord0;

// Blothera: leaves, grass, flowers, crops, sugar cane and bamboo sway in the weather's wind
// (Harry, 2026-11-02).
//
// Which corners move: the pack's plant models (make_sway.py) mark them where they sit on the
// texture: the face's side edges pulled in 0.06 of a pixel (the key), and its top or foot edge
// a whisker off a whole pixel, in steps of 0.02 (the weight): 1 the middle of a two-block plant,
// 2 the top of a plant, 3 every corner of a stalk (sugar cane, bamboo), 4 the top of a two-block
// plant, 5 every corner of a leaf block (make_leaves.py, our bushy leaves). On the
// texture, not in the height: the game nudges short grass and ferns down a random amount.
// Nothing else carries the key, so nothing else moves.
//
// The wind: the weather sends it in the cloud fade distance, which nothing here draws by
// (make_atmosphere.py, wind()): 2 for each of 16 compass steps it blows toward, plus its
// strength times 1.9. 32 or more is no wind sent: still air.
//
// Time: GameTime is the world's ticks round a twenty-minute cycle, so every wave below turns a
// whole number of times in it, and nothing jumps when it comes round.

const float TAU = 6.2831853;
const float KEY = 0.06;
const float STEP = 0.02;

// How far a texture coordinate sits off a whole pixel of the atlas, 0 to 0.5.
float offPixel(float texel) {
    return abs(fract(texel + 0.5) - 0.5);
}

int swayMark(vec2 uv) {
    vec2 texel = uv * vec2(TextureSize);
    if (abs(offPixel(texel.x) - KEY) > 0.006) {
        return 0;
    }
    float weight = offPixel(texel.y);
    float steps = round(weight / STEP);
    if (steps < 1.0 || steps > 5.0 || abs(weight - steps * STEP) > 0.005) {
        return 0;
    }
    return int(steps);
}

float wave(float cycles, float phase) {
    return sin(TAU * cycles * GameTime + phase);
}

vec3 sway(vec3 position, int mark) {
    float carried = FogCloudsEnd;
    vec2 toward = vec2(0.0, 1.0);
    float strength = 0.0;
    if (carried < 31.95) {
        float compassStep = floor(carried * 0.5 + 0.001);
        strength = clamp((carried - compassStep * 2.0) / 1.9, 0.0, 1.0);
        float yaw = radians(compassStep * 22.5);
        toward = vec2(-sin(yaw), cos(yaw));
    }
    vec2 across = vec2(-toward.y, toward.x);

    vec3 world = position + vec3(ChunkPosition);

    // Gusts rolling over the land downwind, about five blocks a second, stronger in a gale.
    float roll = 0.5 + 0.5 * sin(dot(world.xz, toward) * 0.1 - TAU * 96.0 * GameTime);
    float gust = mix(1.0, 0.35 + 1.3 * roll * roll, strength);
    // Each plant a little out of step with its neighbours.
    float phase = sin(world.x * 0.83) * 2.1 + cos(world.z * 0.71) * 2.3 + sin((world.x + world.z) * 0.37) * 1.7;

    if (mark == 5) {
        // Leaves move as a canopy: a slow sway downwind and back that rolls through the tree,
        // and a lighter, quicker stir, both smooth over the tree, so neighbouring corners move
        // nearly together and a leaf block keeps its shape (Harry, 2026-11-02: corners moving
        // each on its own "look like jelly"). Shared corners move alike, so no cracks open. Not
        // by the light, which differs between faces meeting at a corner; leaves are nearly
        // always in the open anyway. A breeze moves them about a pixel, a gale a few.
        float field = dot(world, vec3(0.29, 0.19, 0.23));
        float reach = (0.035 + 0.075 * strength) * gust;
        float canopy = 0.6 * wave(300.0, field + phase * 0.3) + 0.4 * wave(540.0, field * 1.4 + 1.0);
        float stir = 0.008 + 0.02 * strength;
        vec3 move = vec3(toward.x, 0.0, toward.y) * reach * canopy;
        move += vec3(wave(900.0, field * 2.1), 0.4 * wave(1020.0, field * 1.7 + 1.0), wave(960.0, field * 2.6 + 2.0)) * stir;
        return move;
    }

    if (mark == 3) {
        // Sugar cane and bamboo: the whole stalk leaning a little and swaying, the sway rolling up
        // it, so a stalk of any height moves as one and its segments never part (Harry,
        // 2026-11-02: "SLIGHTLY ... they can be very very tall").
        float reach = (0.012 + 0.035 * strength) * gust;
        float sway = 0.4 + 0.6 * (0.5 + 0.5 * wave(360.0, phase - world.y * 0.25));
        vec2 move = toward * reach * sway + across * reach * 0.3 * wave(600.0, phase * 1.2 - world.y * 0.3);
        return vec3(move.x, 0.0, move.y);
    }

    float weight = mark == 1 ? 0.5 : (mark == 2 ? 1.0 : (mark == 4 ? 1.7 : 0.0));
    // Out of the open sky the wind does not reach a plant: indoors, under a roof, in a cave.
    float open = smoothstep(0.45, 0.95, float(UV2.y) / 240.0);
    if (weight == 0.0 || open <= 0.0) {
        return vec3(0.0);
    }
    // A steady bend downwind, more than doubling as the wind rises, and a sway about it: slow in
    // a breeze, quicker and shakier in a gale.
    float bend = (0.03 + 0.06 * strength + 0.18 * strength * strength) * gust;
    float swing = 0.025 + 0.06 * strength;
    float flutter = wave(420.0, phase) * (1.0 - 0.5 * strength)
            + wave(1080.0, phase * 1.7) * (0.3 + 0.5 * strength)
            + wave(1920.0, phase * 2.3) * 0.2 * strength;
    vec2 move = toward * (bend + swing * flutter) + across * swing * 0.35 * wave(660.0, phase * 1.3);
    move *= weight * open;
    // A stalk bent over is a little shorter.
    return vec3(move.x, -dot(move, move) * 0.6, move.y);
}

void main() {
    vec3 position = Position;
    int mark = swayMark(UV0);
    if (mark > 0) {
        position += sway(Position, mark);
    }
    vec3 pos = position + (ChunkPosition - CameraBlockPos) + CameraOffset;
    gl_Position = ProjMat * ModelViewMat * vec4(pos, 1.0);

    sphericalVertexDistance = fog_spherical_distance(pos);
    cylindricalVertexDistance = fog_cylindrical_distance(pos);
    vertexColor = Color * sample_lightmap(Sampler2, UV2);
    texCoord0 = UV0;
}
