# Blothera resource pack

Drop your PNGs in and zip the folder:

    assets/blothera/textures/item/lock.png
    assets/blothera/textures/item/key.png
    assets/blothera/textures/item/crown.png
    assets/blothera/textures/entity/equipment/humanoid/crown.png

Any square power-of-two size works. Vanilla items are 16x16; 32x32 is fine and
needs declaring nowhere, since `pack.mcmeta` carries no resolution. Different
items in the same pack may differ.

Nothing else needs authoring. `minecraft:item/generated` extrudes a flat item
from the texture, so the model files here are four lines each and never need
touching again. Higher resolution gives finer detail on the extruded edges,
which is worth having at 32 and starts to look fussy past about 128.

## Worn armour is a second texture

Anything you wear has two appearances and they come from different files. The
crown is the example:

    items/crown.json                             icon definition
    models/item/crown.json                       icon model
    textures/item/crown.png                      the icon, flat, any square size

    equipment/crown.json                         worn definition
    textures/entity/equipment/humanoid/crown.png the worn layer

The worn one is not a flat icon. It is an armour layer mapped onto the player
model, laid out like vanilla's own armour textures, so it has to be authored
against that template rather than drawn as a picture of a crown. Set only the
icon and the crown looks right in the hand and turns back into a gold helmet the
moment somebody puts it on.

The code side is `item_model` for the icon and the `equippable` component's
`assetId` for the worn layer. Both point at `blothera:crown`; the game knows
which folder to look in from which component asked.

Trims are a separate thing again and only needed if you want smithing-table trim
overlays on these. Nothing here uses them.

## Adding another item

Copy one file from `items/` and one from `models/item/`, drop in a PNG, and set
the item's `item_model` component to `blothera:<name>` in code. If it is worn,
add an `equipment/<name>.json` and the humanoid texture as above.

The zip must have `pack.mcmeta` at its root, not the folder above it:

    cd ResourcePack/blothera && zip -r ../blothera-resources.zip .

Then host the zip and point `resource-pack` in server.properties at it, with
`resource-pack-sha1` set to the zip's SHA-1.

`min_format` / `max_format` are copied from the DnT pack already in
`Datapacks/`, which is known to load on this server. If the server updates and
the pack stops applying, that pair is what needs raising.

Nobody is broken by not having this pack: an item model the client does not
recognise falls back to the base item, so a Lock shows as an iron nugget and a
Key as a tripwire hook, and both still work exactly the same.
