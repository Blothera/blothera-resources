# Blothera resource pack

Drop your two PNGs in and zip the folder:

    assets/blothera/textures/item/lock.png
    assets/blothera/textures/item/key.png

Any square power-of-two size works. Vanilla items are 16x16; 32x32 is fine and
needs declaring nowhere, since `pack.mcmeta` carries no resolution. Different
items in the same pack may differ.

Nothing else needs authoring. `minecraft:item/generated` extrudes a flat item
from the texture, so the model files here are four lines each and never need
touching again. Higher resolution gives finer detail on the extruded edges,
which is worth having at 32 and starts to look fussy past about 128.

To add another custom item later, copy one file from `items/` and one from
`models/item/`, drop in a PNG, and set the item's `item_model` component to
`blothera:<name>` in code.

The zip must have `pack.mcmeta` at its root, not the folder above it:

    cd ResourcePack/blothera && zip -r ../blothera-resources.zip .

Then host the zip and point `resource-pack` in server.properties at it, with
`resource-pack-sha1` set to the zip's SHA-1.

`min_format` / `max_format` are copied from the DnT pack already in
`Datapacks/`, which is known to load on this server. If the server updates and
the pack stops applying, that pair is what needs raising.

Nobody is broken by not having this pack: an item model the client does not
recognise falls back to the base item, so a Lock shows as an iron nugget and a
Key as a tripwire hook, and both still work exactly the same.
